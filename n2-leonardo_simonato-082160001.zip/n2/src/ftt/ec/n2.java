package ftt.ec;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.net.ssl.*;
import javax.activation.*;

/**
 * Servlet implementation class n2
 */
@WebServlet("/n2")
public class n2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public n2() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String pra = request.getParameter("pra");
		String pname = request.getParameter("pname");
		String pcpf = request.getParameter("pcpf");
		String pdate = request.getParameter("pdate");
		String pemail = request.getParameter("pemail");
		String prenda = request.getParameter("prenda");
		String prg = request.getParameter("prg");
		String psexo = request.getParameter("psexo");
		String cMsg = "";
		String cCabec = "";
		
		cMsg += "RA = " + pra;
		cMsg += "\r\nNome Completo= " + pname;
		cMsg += "\r\nRG= " + prg;
		cMsg += "\r\nCPF= " + pcpf;
		cMsg += "\r\nData de Nascimento= " + pdate;
		cMsg += "\r\nSexo= " + psexo;
		cMsg += "\r\ne-mail= " + pemail;
		cMsg += "\r\nRenda= " + prenda;
		
		cCabec += "Rematr�cula - RA: " + pra + " Nome: " + pname;
		
		
		Properties props = new Properties();
		
		/* Par�metros de conex�o com o Gmail */
		props.put("mail.smtp.host", "smtp.gmail.com");
	    props.put("mail.smtp.auth", "true");
	    //props.put("mail.debug", "true");
	    //props.put("mail.smtp.debug", "true");
	    //props.put("mail.mime.charset", "ISO-8859-1");
        props.put("mail.smtp.port", "465");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.ssl.enable", "true");
        props.put("mail.smtp.socketFactory.port", "465");
        //props.put("mail.smtp.socketFactory.fallback", "false");
        //props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
	    props.put("mail.smtp.ssl.trust", "smtp.gmail.com");

	    Session session = Session.getInstance(props,new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() 
					{
						return new PasswordAuthentication("rematleo","leo@123456");
					}
			}
	    );
		 
	    /* Ativa Debug para sess�o */
	    session.setDebug(true);
	 
	    try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("rematleo@gmail.com")); // Remetente
			Address[] toUser = InternetAddress.parse(pemail); // Destinat�rio
			
			// Monta mensagem
			message.setRecipients(Message.RecipientType.TO, toUser);
			message.setSubject(cCabec);  // Assunto
			message.setText(cMsg);  // Mensagem
			
			/* M�todo para enviar a mensagem criada */
			Transport.send(message);
		 
			System.out.println("Feito!!!");
		 
	    } catch (MessagingException e) {
	    	throw new RuntimeException(e);
	    }
		
		/*
		response.getWriter()
					 .append("RA = ")
					 .append(pra)
					 .append("</br>Nome Completo= ")
					 .append(pname)
					 .append("</br>RG= ")
					 .append(prg)
					 .append("</br>CPF= ")
					 .append(pcpf)
					 .append("</br>Data de Nascimento= ")
					 .append(pdate)
					 .append("</br>Sexo= ")
					 .append(psexo)
					 .append("</br>e-mail= ")
					 .append(pemail)
					 .append("</br>Renda= ")
					 .append(prenda);
		*/
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPut(HttpServletRequest, HttpServletResponse)
	 */
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doDelete(HttpServletRequest, HttpServletResponse)
	 */
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
